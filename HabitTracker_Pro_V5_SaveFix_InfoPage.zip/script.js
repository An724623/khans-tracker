let habits = JSON.parse(localStorage.getItem("habits") || "[]");
const habitList = document.getElementById("habitList");

function saveHabits() {
  localStorage.setItem("habits", JSON.stringify(habits));
  renderHabits();
  renderChart();
}

function addHabit(name = null) {
  const input = document.getElementById("habitInput");
  const value = name || input.value.trim();
  if (value) {
    habits.push({ name: value, completed: [] });
    input.value = "";
    saveHabits();
  }
}

function removeHabit(index) {
  habits.splice(index, 1);
  saveHabits();
}

function toggleDay(habitIndex, day) {
  const comp = habits[habitIndex].completed;
  const i = comp.indexOf(day);
  if (i > -1) comp.splice(i, 1);
  else comp.push(day);
  saveHabits();
}

function renderHabits() {
  habitList.innerHTML = "";
  const days = ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"];
  habits.forEach((habit, i) => {
    const li = document.createElement("li");
    li.className = "habit";
    li.innerHTML = `
      <span>${habit.name}</span>
      <div>
        ${days.map((d, di) =>
          `<button onclick="toggleDay(${i}, '${d}')" style="background:${
            habit.completed.includes(d) ? 'green' : '#333'
          }">${d[0]}</button>`).join("")}
        <button onclick="removeHabit(${i})">❌</button>
      </div>`;
    habitList.appendChild(li);
  });
}

function toggleDarkMode() {
  document.body.classList.toggle("light-mode");
}

function exportData() {
  const blob = new Blob([JSON.stringify(habits)], { type: "application/json" });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = "habits.json";
  a.click();
}

function importData() {
  const input = document.createElement("input");
  input.type = "file";
  input.accept = "application/json";
  input.onchange = e => {
    const file = e.target.files[0];
    const reader = new FileReader();
    reader.onload = () => {
      habits = JSON.parse(reader.result);
      saveHabits();
    };
    reader.readAsText(file);
  };
  input.click();
}

function speakHabit() {
  const rec = new(window.SpeechRecognition || window.webkitSpeechRecognition)();
  rec.lang = "en-US";
  rec.onresult = e => addHabit(e.results[0][0].transcript);
  rec.start();
}

function setLanguage(lang) {
  const messages = {
    en: ["Keep going!", "You're doing great!", "Don't give up!"],
    hi: ["शानदार!", "लगे रहो!", "आप कर सकते हैं!"]
  };
  const msg = messages[lang][Math.floor(Math.random() * messages[lang].length)];
  document.getElementById("quote").innerText = msg;
}

function renderChart() {
  if (!document.getElementById("habitChart")) return;
  const labels = habits.map(h => h.name);
  const data = habits.map(h => h.completed.length);
  const ctx = document.getElementById('habitChart').getContext('2d');
  if (window.habitChart) window.habitChart.destroy();
  window.habitChart = new Chart(ctx, {
    type: 'bar',
    data: {
      labels: labels,
      datasets: [{
        label: '# of Completions',
        data: data,
        backgroundColor: 'green'
      }]
    }
  });
}

renderHabits();
renderChart();